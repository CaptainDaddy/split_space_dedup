//video_units.cpp
//Joshua Suggs
//January 2012
#include "video_units.h"


int rgb_euclidean_distance(rgb_cell rgb_one, rgb_cell rgb_two){
   return sqrt((rgb_one.red-rgb_two.red)*(rgb_one.red-rgb_two.red)+
               (rgb_one.green-rgb_two.green)*(rgb_one.green-rgb_two.green)+
               (rgb_one.blue-rgb_two.blue)*(rgb_one.blue-rgb_two.blue)); 
