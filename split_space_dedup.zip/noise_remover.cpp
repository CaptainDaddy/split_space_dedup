//noise_remover.cpp
//Joshua Suggs
//January 2012

#include "noise_remover.h"
/*
class noise_remover{
   public:
      noise_remover();       
      noise_remover(pixel_space);//write copy constructor in pixel_space
      noise_remover(pixel_space,int);
      build_count_tree();
      set_replacements();
      smooth_the_field();
      pixel_space * return_pixel_space();
   private:
      pixel_space video_space;
      count_tree_node_pointer root;
      count_tree_node_list_pointer start;
      int tolerance;
}*/

noise_remover::noise_remover(){tolerance=0;video_space=NULL;root=NULL;start=NULL}
noise_remover::noise_remover(pixel_space in_space){
   tolerance=0;root=NULL;start=NULL;
   video_space=in_space;
}
noise_remover::noise_remover(pixel_space in_space, int tolerance){
   root=NULL;start=NULL;
   tolerance=0;
   video_space=in_space;
}
void noise_remover::build_count_tree(){
   int x1,x2,x4,length1,length2,length3;
   count_tree_node_pointer current;
   int * dimensions_copy=video_space->get_dimensions();
   if(video_space!=NULL){
      length1=dimensions_copy[0];
      length2=dimensions_copy[1];
      length3=dimensions_copy[2];
   }
   free(dimensions_copy);
   if(root!=NULL) delete_count_tree(root);
   root=(count_tree_node_pointer)malloc(sizeof(count_tree_node));
   current=root;
   ctn_add_value(current, this->video_space->data_space[0][0][0]);
   for(x1=0;x1<length1;x1++)
      for(x2=0;x1<length2;x2++)
         for(x3=0;x1<length3;x3++)
            ctn_add_value(current,data_space[x1][x2][x3];
   ctn_subtract_value(current,data_space[0][0][0];
}
void noise_remover::set_replacements(){
   
